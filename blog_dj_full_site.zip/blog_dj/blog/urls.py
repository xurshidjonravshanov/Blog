from django.urls import path
from .views import front_page, single, search

app_name = 'blog'

urlpatterns = [
    path('', front_page, name='Home'),
    path('search/', search, name='search'),
    path('post_detail/<slug:slug>/', single, name='single'),
    
]